using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HeroScript : MonoBehaviour
{
    [SerializeField] private float Speed;
    private float HorizontalSpeed;
    public GameObject Player;
    private void Update()
    {
        if (Input.GetMouseButton(0))
        {
            if (Input.mousePosition.x < Screen.width /2 )
            {
                OnLeft();
            }
            else
            {
                OnRight();
            }
        }
        else
        {
            Stop();
        }
    }

    private void Start()
    {
        ScoreScript.Instance.Score = 0;
    }
    private void FixedUpdate()
    {
        transform.Translate(HorizontalSpeed, 0, 0);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Meteor")
        {
            if (ScoreScript.Instance.MaxScore < ScoreScript.Instance.Score)
            {
                ScoreScript.Instance.MaxScore = ScoreScript.Instance.Score;
                PlayerPrefs.SetInt("MaxScore", ScoreScript.Instance.MaxScore);
            }
            SceneManager.LoadScene(0);
        }
    }
    public void OnRight()
    {
        if (Player.transform.position.x < 2)
            HorizontalSpeed = Speed;
        else
            Player.transform.position = new Vector2(2, Player.transform.position.y);
    }
    public void OnLeft()
    {
        if (Player.transform.position.x > -2)
            HorizontalSpeed = -Speed;
        else
            Player.transform.position = new Vector2(-2, Player.transform.position.y);
    }
    public void Stop()
    {
        HorizontalSpeed = 0;
    }
    public void ToMainMenu()
    {
        SceneManager.LoadScene(0);
    }
}
