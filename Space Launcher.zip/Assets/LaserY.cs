using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LaserY : MonoBehaviour
{
    void Update()
    {
        transform.Translate(new Vector2(0, 3f * Time.deltaTime));
    }
    public void OnCollisionEnter2D(Collision2D Meteor)
    {
        if (Meteor.gameObject.tag == "Meteor")
        {
            ScoreScript.Instance.Score++;
            Destroy(Meteor.gameObject);
            Destroy(gameObject);
        }
    }
}
