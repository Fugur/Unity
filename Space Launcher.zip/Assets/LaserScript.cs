using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserScript : MonoBehaviour
{
    public GameObject laser;
    private float _laserSpeed = 1f;
    public float laserSpeed
    {
        get
        {
            return _laserSpeed;
        }
        set
        {
            if(value < 1f)
            {
                _laserSpeed = value;
            }
        }
    }
    private void Start()
    {
        StartCoroutine(LaserFire());
    }

    IEnumerator LaserFire()
    {
        yield return new WaitForSeconds(laserSpeed);
        Instantiate(laser, transform.position, Quaternion.identity);
        StartCoroutine(LaserFire());
    }
}
