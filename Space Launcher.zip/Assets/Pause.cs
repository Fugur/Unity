using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pause : MonoBehaviour
{
    public bool isPaused;

    public GameObject pauseMenuCanvas;

    public void PauseGame()
    {
        if (isPaused)
            isPaused = false;
        else if(!isPaused)
            isPaused = true;
    }
    void Update()
    {
        if (isPaused)
        {
            pauseMenuCanvas.SetActive(true);//������ ����� �������� � SetActive.
            Time.timeScale = 0f;
        }
        else
        {
            pauseMenuCanvas.SetActive(false);
            Time.timeScale = 1f;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            isPaused = !isPaused;
        }
    }
}
