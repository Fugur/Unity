using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorsScript : MonoBehaviour
{
    public GameObject[] Meteors;
    private int randomMeteor;
    private float random;
    private float randomPos;
    private void Start()
    {
        StartCoroutine(MeteorsSpawn());
    }
    private void Update()
    {
        random = 1f;
        randomPos = Random.Range(-2, 3);
    }
    IEnumerator MeteorsSpawn()
    {
        yield return new WaitForSeconds(random);
        randomMeteor = Random.Range(0, Meteors.Length);
        random /= 2;
        MeteorsSpawnMethod();
        StartCoroutine(MeteorsSpawn());
    }
    private void MeteorsSpawnMethod()
    {
        Instantiate(Meteors[randomMeteor], new Vector2(randomPos, transform.position.y), Quaternion.identity);
    }
}
