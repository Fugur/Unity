using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScript : MonoBehaviour
{
    public static ScoreScript Instance { get; private set; } // static singleton
    private void Awake()
    {
        if (Instance == null) { Instance = this; }
        else { Destroy(gameObject); }
    }
    [SerializeField] Text MaxScoreText;
    [SerializeField] Text ScoreText;
    private int _maxScore;
    public int MaxScore {
        get
        {
            return _maxScore;
        }
        set
        {
            if (value > 0)
            {
                MaxScoreText.text = $"Best score: {MaxScore}";
                _maxScore = value;
            }
        }
    }

    private int _score;
    public int Score
    {
        get
        {
            return _score;
        }
        set
        {
            if (value >= 0 )
            {
                _score = value;
                ScoreText.text = $"Score: {Score}";
            }
        }
    }



    private void Start()
    {
        MaxScore = PlayerPrefs.GetInt("MaxScore");
    }
}
